define([], function() {
'use strict';
return {
    test: '你好世界'
};
});
